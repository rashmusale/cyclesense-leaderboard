def compute_new_nav(old_nav, r_decimal, pitch_points, emotion_points):
    return (old_nav * (1 + r_decimal)) + pitch_points + emotion_points
