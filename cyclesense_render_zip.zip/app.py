import os, sqlite3
from flask import Flask, render_template, g

DB_PATH = os.getenv("DB_PATH", "db.sqlite3")
app = Flask(__name__, static_folder="static", template_folder="templates")

def get_db():
    db = getattr(g, "_db", None)
    if db is None:
        db = g._db = sqlite3.connect(DB_PATH, check_same_thread=False)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL;")
        init_schema(db)
    return db

@app.teardown_appcontext
def close_db(exc):
    db = getattr(g, "_db", None)
    if db is not None:
        db.close()

def init_schema(con):
    con.executescript('''
    CREATE TABLE IF NOT EXISTS Team (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      nav_start REAL DEFAULT 10,
      nav_current REAL DEFAULT 10,
      pitch_total INTEGER DEFAULT 0,
      emotion_total INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS Round (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      number INTEGER NOT NULL,
      color_phase TEXT CHECK(color_phase IN ('GREEN','BLUE','ORANGE','RED')),
      scenario_code TEXT,
      black_card_code TEXT,
      team_results TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    ''' )

@app.route("/")
def dashboard():
    con = get_db()
    # seed demo teams
    if con.execute("SELECT COUNT(*) AS c FROM Team").fetchone()["c"] == 0:
        con.execute("INSERT INTO Team(name) VALUES ('Team Alpha')")
        con.execute("INSERT INTO Team(name) VALUES ('Team Beta')")
        con.commit()

    latest = con.execute('''
        WITH tr AS (
          SELECT
            CAST(json_extract(j.value, '$.team_id') AS INTEGER) AS team_id,
            r.number AS round_number
          FROM Round r, json_each(r.team_results) j
        ),
        latest AS (
          SELECT team_id, MAX(round_number) AS max_round
          FROM tr GROUP BY team_id
        )
        SELECT t.id AS team_id, t.name, t.nav_current, t.pitch_total, t.emotion_total,
               latest.max_round
        FROM Team t
        LEFT JOIN latest ON latest.team_id = t.id
        ORDER BY t.name COLLATE NOCASE;
    ''').fetchall()

    alloc_rows = con.execute('''
        SELECT
          r.number AS round_number,
          CAST(json_extract(j.value, '$.team_id') AS INTEGER) AS team_id,
          json_extract(j.value, '$.allocation_equity_pct') AS equity_pct,
          json_extract(j.value, '$.allocation_debt_pct')   AS debt_pct,
          json_extract(j.value, '$.allocation_gold_pct')   AS gold_pct,
          json_extract(j.value, '$.allocation_cash_pct')   AS cash_pct,
          json_extract(j.value, '$.rebalance_pct_used')    AS rebalance_used
        FROM Round r, json_each(r.team_results) j
    ''').fetchall()

    alloc_index = {(r["team_id"], r["round_number"]): r for r in alloc_rows}

    teams = []
    for row in latest:
        a = alloc_index.get((row["team_id"], row["max_round"]))
        teams.append({
            "team_id": row["team_id"],
            "name": row["name"],
            "nav_current": row["nav_current"],
            "pitch_total": row["pitch_total"],
            "emotion_total": row["emotion_total"],
            "equity_pct": a["equity_pct"] if a else None,
            "debt_pct": a["debt_pct"] if a else None,
            "gold_pct": a["gold_pct"] if a else None,
            "cash_pct": a["cash_pct"] if a else None,
            "rebalance_used": a["rebalance_used"] if a else None,
        })

    return render_template("dashboard.html", teams=teams)

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
